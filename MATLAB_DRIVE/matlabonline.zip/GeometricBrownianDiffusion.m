function g = GeometricBrownianDiffusion(t,x,p)
sigma = p(2);
g = sigma*x;
end