function f = GeometricBrownianDrift(t,x,p)
lambda = p(1);
f = lambda*x;
