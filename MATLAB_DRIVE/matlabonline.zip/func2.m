function xdot = func1(t,x, lamb)
xdot = lamb*x;
end
