function g = VanderPolDiffusion1(t,x,p)

sigma = p(2);
g = [0.0; sigma];
end