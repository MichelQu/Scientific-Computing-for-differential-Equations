function xdot = func1(t,x)
xdot = cos(t)*x;
end
