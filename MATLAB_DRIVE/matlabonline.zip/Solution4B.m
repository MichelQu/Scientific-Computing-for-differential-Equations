mu = [1,3,10,100];
x0 =  [2.0;0.0];
h0 = 0.2;
abstol = [1e-12, 1e-7, 1e-5, 1e-3];
reltol = [1e-12, 1e-7, 1e-5, 1e-3];
tiledlayout(8,2)

for j = drange(1:4)
    for i = drange(1:4)

        [T,X] = ClassicalRungeKuttaAdaptiveStep(@VanDerPol,[0, 5*mu(i)],x0,h0,abstol(j),reltol(j),mu(i));
        nexttile
        plot(T,X)
        title(['μ = ' num2str(mu(i)) '   tol =' num2str(abstol(j))])

    %error
    %[T,X] = ExplicitEulerAdaptiveStep(@VanDerPol,[0, 5*mu(i)],x0,h0,abstol,reltol,mu(i));
    %nexttile
    %plot(T,X)

    end
end