function [T,X] = ImplicitEulerAdaptiveStep(fun, tspan,x0,h0,abstol,reltol,varargin)

%Error controller parameters
epstol = 0.8; % target
facmin = 0.1; % maximum decrease factor
facmax = 5.0; % maximum increase factor
%Intergration interval
t0 = tspan(1);
tf = tspan(2);
%Initial conditions
t = t0;
h= h0;
x = x0;
%Output

T=t;
X=x';
%%
function [T, X] = ImplicitEulerFixedSS2(funJac, tspan,x0,h0,abstol,reltol ,varargin)
nx = size(x0,1);
%Intergration interval
t0 = tspan(1);
tf = tspan(2);
X = zeros(nx, N+1);
T = zeros(1,N+1);
tol = 1.0e-8;
maxit = 100;
T(:,1) = tspan(1);
X(:,1) = x0;

for k=1:N
    f = feval(funJac, T(k),X(:,k),varargin{:});
    T(:,k+1) = T(:,k) +dt;
    xinit = X(:,k) + f*dt;
    X(:,k+1) = NewtonsMethodODE(funJac,T(:,k),X(:,k),dt, xinit, tol,maxit, varargin{:});

end

T= T';
X= X';

%% Main algo
while t < tf
    if (t+h>tf)
        h = tf-t;
    end
    f= feval(fun,t,x,varargin{:});
    
    AcceptStep = false;
    while ~AcceptStep
        %Take step of size h
        x1 = x+ h*f;
        
        %Take step of size h/2
        hm = 0.5*h;
        tm = t+hm;
        xm = x+hm*f;
        fm = NewtonsMethodODE(FunJac, tm, xm, hm, xinit, epstol, maxit, varargin);
        x1hat = xm +hm*fm;
        
        %Error estimation
        e = x1hat-x1;
        r = max(abs(e)./max(abstol,abs(x1hat).*reltol));
        
        AcceptStep = (r <= 1.0);
        if AcceptStep
            t = t+h;
            x = x1hat;
            
            T = [T;t];
            X = [X;x'];
        end
        %asymptotic step size controller
        h = max(facmin,min(sqrt(epstol/r),facmax))*h;    
    end
end